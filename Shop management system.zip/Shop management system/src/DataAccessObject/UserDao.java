/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Stores Table Quries//
package DataAccessObject;

import javax.swing.JOptionPane;

import model.User;
import java.sql.*;
import DataAccessObject.DbOperations;
import java.util.ArrayList;

/**
 *
 * @author Nihal
 */
public class UserDao {
        public static void main(String args[]){
    }

    public static void save(User user) {
        String query = "insert into DUser (UName,UEmail,UMobile_Number,Address,Password,Security_Question,Answer,Status) values('" + user.getName() + "','" + user.getEmail() + "','" + user.getMobileNumber() + "','" + user.getAddress() + "','" + user.getPassword() + "','" + user.getSecurityQuestion() + "','" + user.getAnswer() + "','false')";
        DbOperations.setDataOrDelete(query, "Registered Successfully! Wait for Admin Approval");

    }

    public static User login(String email, String password) {
        User user = null;
        try {
            ResultSet rs = DbOperations.getData("select * from DUser where UEmail='" + email + "' and Password='" + password + "'");
            while (rs.next()) {
                user = new User();
                user.setStatus(rs.getString("Status"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return user;
    }

    public static User getSecurityQuestion(String email) {
        User user = null;
        try {
            ResultSet rs = DbOperations.getData("Select * from DUser where UEmail ='" + email + "'");
            while(rs.next()){
                user = new User();
                user.setSecurityQuestion(rs.getString("Security_Question"));
                user.setAnswer(rs.getString("Answer"));
            
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return user;
    }
    public static void update(String email,String newPassword){
    String query="update DUser set Password='"+newPassword+"'where UEmail='"+email+"'";
    DbOperations.setDataOrDelete(query,"Password Changed Successfully");
    }
    public static ArrayList<User> getAllrecords(String email){
     ArrayList<User> arrayList = new ArrayList<>();
     try{
     ResultSet rs= DbOperations.getData("select * from DUser where UEmail like'%"+email+"%'");
     while(rs.next()){
     User user = new User();
     user.setId(rs.getInt("UId"));
     user.setName(rs.getString("UName"));
     user.setEmail(rs.getString("UEmail"));
     user.setMobileNumber(rs.getString("UMobile_Number"));
     user.setAddress(rs.getString("Address"));
     user.setSecurityQuestion(rs.getString("Security_Question"));
     user.setStatus(rs.getString("Status"));
     arrayList.add(user);
     }
     }
     catch(Exception e){
         JOptionPane.showMessageDialog(null,e);
     }
     return arrayList;
    }
    
    public static void changeStatus(String email,String status){
    
    String query="update DUser set Status='"+status+"' where UEmail='"+email+"'";
    DbOperations.setDataOrDelete(query, "Status Changed Successfully");
    }
    
    public static void changePassword(String email,String oldPassword, String newPassword){
        try{
            ResultSet rs = DbOperations.getData("Select * from DUser where UEmail='"+email+"' and Password='"+oldPassword+"'");
            if(rs.next()){
                update(email, newPassword);
            }
            else{
                JOptionPane.showMessageDialog(null, "Old Password is wrong");
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public static void changeSecurityQuestion(String email,String password,String securityQuestion,String answer){
        try{
            ResultSet rs = DbOperations.getData("select * from DUser where UEmail='"+email+"' and Password='"+password+"'");
            if(rs.next()){
                update(email, securityQuestion, answer);
            }
            else
                JOptionPane.showMessageDialog(null,"Incorrect Password");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public static void update(String email,String securityQuestion, String answer){
        String query="update DUser set Security_Question='"+securityQuestion+"',Answer='"+answer+"' where UEmail='"+email+"'";
        DbOperations.setDataOrDelete(query, "Security Question Changed Successfully");
    }
    
    public static int userIdUsingEmail(String email){
        String query= "select * from DUser where UEmail='"+email+"' ";
        int id=0;
        try{
            ResultSet rs = DbOperations.getData(query);
            while(rs.next()){
             id=  rs.getInt("UId");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return id;
    }
}
