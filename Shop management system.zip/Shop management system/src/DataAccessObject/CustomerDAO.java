/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataAccessObject;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Customer;
/**
 *
 * @author uzaifisani
 */
public class CustomerDAO {
    
    public static void saveCustInfo(Customer customer){
        String query="insert into Customer_Data(CName,CMobileNo,CEmail) VALUES ('"+customer.getcName()+"','"+customer.getcNumber()+"','"+customer.getcEmail()+"')";
        DbOperations.setDataOrDelete(query, "Customer Added Successfully");
    }
    
    public static void UpdateCustInfo(Customer customer){
        String query="update Customer_Data set CName='"+customer.getcName()+"',CMobileNo='"+customer.getcNumber()+"',CEmail='"+customer.getcEmail()+"' where CId='"+customer.getCid()+"' ";
        DbOperations.setDataOrDelete(query, "Customer Details Updated Successfully!");
    }
    
    public static ArrayList<Customer> getAllCustomers(){
        ArrayList<Customer> arrayList = new ArrayList<>();
        try{
            ResultSet rs = DbOperations.getData("select * from Customer_Data");
            while(rs.next()){
                Customer customer = new Customer();
                customer.setCid(rs.getInt("CId"));
                customer.setcName(rs.getNString("CName"));
                customer.setcNumber(rs.getNString("CMobileNo"));
                customer.setcEmail(rs.getNString("CEmail"));
                arrayList.add(customer);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
         return arrayList;
    }
    
    public static Customer getCustomerByname(String name){
         Customer customer = new Customer();
         try{
         ResultSet rs = DbOperations.getData("select * from Customer_Data where CName='"+name+"'");
         while(rs.next()){
                customer.setCid(rs.getInt("CId"));
                customer.setcName(rs.getNString("CName"));
                customer.setcNumber(rs.getNString("CMobileNo"));
                customer.setcEmail(rs.getNString("CEmail"));
            }
         }
         catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
         }
     return customer;
     }
    
     public static ArrayList<Customer> filterProductByname(String name){
        ArrayList<Customer> arrayList = new ArrayList<>();
        try{
        ResultSet rs = DbOperations.getData("SELECT * FROM Customer_Data WHERE CName LIKE '%"+name+"%';");
        while(rs.next()){
        Customer customer = new Customer();
        customer.setCid(rs.getInt("CId"));
        customer.setcName(rs.getNString("CName"));
        customer.setcNumber(rs.getNString("CMobileNo"));
        customer.setcEmail(rs.getNString("CEmail"));
        arrayList.add(customer);
        }
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
        return arrayList;
    
    }
}
