/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessObject;

import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Bill;
import model.BillProduct;
import model.CustomerDetails;

/**
 *
 * @author uzaifisani
 */
public class BillDao {
    public static String getId(){
        int id=1;
        try{
           ResultSet rs= DbOperations.getData("select max(Bill_id) from Bill_Master");
           if(rs.next()){
               id = rs.getInt(1);
               id = id+1;
           }
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null, e);
        }
        return String.valueOf(id);
    }
    
    public static void BillMasterUpdate(Bill bill){
        String query="insert into Bill_Master (Date,Cid,Created_by) VALUES ('"+bill.getDate()+"','"+bill.getCid()+"','"+bill.getUserId()+"')";
        DbOperations.setDataOrDelete(query, "Bill Master Added");
    }
    public static void BillProductUpdate(BillProduct billProduct){
        String query="insert into Bill_Product(Bill_id,Pid,Price,Quantity,Total_Price) VALUES ('"+billProduct.getBillId()+"','"+billProduct.getPid()+"','"+billProduct.getPrice()+"','"+billProduct.getQuantity()+"','"+billProduct.getTotal_price()+"') ";
        DbOperations.setDataOrDelete(query, "Added to Cart");
    }
    
    public static void AddTotalToBill(int id,Float total){
        String query="Update Bill_Master set Total='"+total+"' where Bill_id='"+id+"' ";
        DbOperations.setDataOrDelete(query, "Bill Data Created Successfully");
    }
    
    
    
    public static ArrayList<CustomerDetails> getAllRecordsByInc(String date){
        ArrayList<CustomerDetails> arrayList = new ArrayList<>();
        try{
            ResultSet rs= DbOperations.getData("select * from customerbillview where Date like '%"+date+"%'");
            while(rs.next()){
            CustomerDetails cd = new CustomerDetails();
            cd.setId(rs.getInt(1));
            cd.setCustomerName(rs.getString(2));
            cd.setMobileNo(rs.getString(3));
            cd.setTotal(rs.getFloat(4));
            cd.setDate(rs.getString(5));
            cd.setCreatedBy(rs.getString(6));
            arrayList.add(cd);
           }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }
    public static ArrayList<CustomerDetails> getAllRecordsByDesc(String date){
        ArrayList<CustomerDetails> arrayList = new ArrayList<>();
        try{
            ResultSet rs= DbOperations.getData("select * from customerbillview where Date like '%"+date+"%' order By Bill_Id DESC");
            while(rs.next()){
            CustomerDetails cd = new CustomerDetails();
            cd.setId(rs.getInt(1));
            cd.setCustomerName(rs.getString(2));
            cd.setMobileNo(rs.getString(3));
            cd.setTotal(rs.getFloat(4));
            cd.setDate(rs.getString(5));
            cd.setCreatedBy(rs.getString(6));
            arrayList.add(cd);
           }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }
    
}
