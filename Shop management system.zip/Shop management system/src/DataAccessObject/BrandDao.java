/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessObject;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Brand;
import java.sql.*;
/**
 *
 * @author Nihal
 */
public class BrandDao {
    
    public static void save(Brand category){
        String query = "insert into Brand (BName) values('"+category.getName()+"')";
        DbOperations.setDataOrDelete(query, "Brand Added Successfully");
    }
    
    public static int BidGetter(String bnmae){
        int id=0;
        try{
        ResultSet rs=DbOperations.getData("select * from Brand where BName='"+bnmae+"'");
        while(rs.next()){
            id= rs.getInt("Bid");
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return id;   
    }
    
    public static String getBrandNameOnId(int id){
        String name=null;
        try{
        ResultSet rs=DbOperations.getData("select * from Brand where Bid='"+id+"'");
        while(rs.next()){
            name= rs.getString("BName");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return name;
    }
    
    public static ArrayList<Brand> getAllRecords(){
        ArrayList<Brand> arrayList = new ArrayList<>();
        try{
            ResultSet rs = DbOperations.getData("select * from brand");
            while(rs.next()){
                Brand category = new Brand();
                category.setId(rs.getInt("Bid"));
                category.setName(rs.getString("BName"));
                arrayList.add(category);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }
    
    public static void delete(String id){
        String query = "delete from Brand where Bid='"+id+"'";
        DbOperations.setDataOrDelete(query,"Brand Deleted Successfully");
    }
}
