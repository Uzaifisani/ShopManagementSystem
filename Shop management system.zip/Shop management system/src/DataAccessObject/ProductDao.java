/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessObject;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Product;
import model.Brand;

/**
 *
 * @author Nihal
 */
public class ProductDao {
     public static void save(Product product){
         String query= "insert into Product(ArticleNo,Brand,Quantity,Mrp,PP) values ('"+product.getArticleNo()+"','"+product.getBrand()+"','"+product.getQuantity()+"','"+product.getMrp()+"','"+product.getPp()+"')";
         DbOperations.setDataOrDelete(query,"Product Added Successfully");
     }
     
     public static ArrayList<Product> getAllRecords(){
         ArrayList<Product> arrayList= new ArrayList<>();
         try{
         ResultSet rs = DbOperations.getData("select * from product");
         while(rs.next()){
         Product product = new Product();
         product.setId(rs.getInt("Pid"));
         product.setArticleNo(rs.getString("ArticleNo"));
         product.setBrand(rs.getInt("Brand"));
         product.setQuantity(rs.getString("Quantity"));
         product.setMrp(rs.getString("Mrp"));
         product.setPp(rs.getString("PP"));
         arrayList.add(product);

         }
                 }
         catch(Exception e){
         JOptionPane.showMessageDialog(null,e);
         }
         return arrayList;
     
     }
    public static void update(Product product){
    String query="update Product set ArticleNo='"+product.getArticleNo()+"',Brand='"+product.getBrand()+"',Quantity='"+product.getQuantity()+"',Mrp='"+product.getMrp()+"',PP='"+product.getPp()+"' where Pid='"+product.getId()+"'";
    DbOperations.setDataOrDelete(query,"Product Updated Successfully");

    }
    public static void updateProduct(String articleNo,String quantity){
    String query=" update Product set Quantity='"+quantity+"' where ArticleNo='"+articleNo+"';";
    DbOperations.setDataOrDelete(query,"Stock Updated Successfully");
    }
    
    public static void delete(String id){
    String query2="Insert into returnProduct Select * from product where id ='"+id+"'";
    DbOperations.setDataOrDelete(query2,"Product Added marked As Returned");
    String query ="delete from product  where id ='"+id+"'";
    DbOperations.setDataOrDelete(query,"Product Deleted Successfully");

    }
    public static void deleteStock(String id){
    String query ="delete from product  where id ='"+id+"'";
    DbOperations.setDataOrDelete(query,"Product Deleted Successfully");
    }
    
    
    public static ArrayList<Product> getAllRecordsByCategory(String category){
        ArrayList<Product> arrayList = new ArrayList<>();
        try{
        ResultSet rs = DbOperations.getData("select * from product where brand='"+category+"'");
        while(rs.next()){
        Product product = new Product();
        product.setArticleNo(rs.getString("name"));
        arrayList.add(product);
        }
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
        return arrayList;
    
    }
        public static ArrayList<Product> filterProductByname(String name,int category){
        ArrayList<Product> arrayList = new ArrayList<>();
        try{
        ResultSet rs = DbOperations.getData("select * from Product where ArticleNo like '%"+name+"%' and Brand='"+category+"' AND Quantity <> 0.0");
        while(rs.next()){
        Product product = new Product();
        product.setArticleNo(rs.getString("articleNo"));
        //product.setQuantity("Quantity");
        arrayList.add(product);
        }
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
        return arrayList;
    
    }
     public static Product getProductByname(String name){
         Product product = new Product();
         try{
         ResultSet rs = DbOperations.getData("select * from Product where ArticleNo='"+name+"'");
         while(rs.next()){
         product.setArticleNo(rs.getString(2));
         product.setBrand(rs.getInt(3));
         product.setMrp(rs.getString(5));
         product.setQuantity(rs.getString(4));
            }
         }
         catch(Exception e){
         JOptionPane.showMessageDialog(null, e);
         }
     return product;
     }
     
     public static Product getProductByQuantity(String name){
         Product product = new Product();
         try{
         ResultSet rs = DbOperations.getData("select * from Product where ArticleNo='"+name+"'");
         while(rs.next()){
         product.setId(rs.getInt(1));
         product.setArticleNo(rs.getString(2));
         product.setQuantity(rs.getString(4));
         }
         }
         catch(Exception e){
         JOptionPane.showMessageDialog(null, e);
         }
     return product;
     }
     
     public static int getProductIdByName(String name){
         int id=0;
         try{
             ResultSet rs= DbOperations.getData("Select * from Product where ArticleNo='"+name+"' ");
             while(rs.next()){
                 id=rs.getInt(1);
             }
         }catch(Exception e){
             JOptionPane.showMessageDialog(null, e);
         }
         return id;
     }
}
