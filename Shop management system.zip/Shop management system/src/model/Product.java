/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Nihal
 */
public class Product {
    private int id;
    private String ArticleNo;
    private int brand;
    private String quantity;
    private String mrp;
    private String pp;
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getArticleNo() {
        return ArticleNo;
    }

    public void setArticleNo(String ArticleNo) {
        this.ArticleNo = ArticleNo;
    }

    public int getBrand() {
        return brand;
    }

    public void setBrand(int brand) {
        this.brand = brand;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getMrp() {
        return mrp;
    }

    public void setMrp(String mrp) {
        this.mrp = mrp;
    }

    public String getPp() {
        return pp;
    }

    public void setPp(String pp) {
        this.pp = pp;
    }

    @Override
    public String toString() {
        return "Product{" + "id=" + id + ", ArticleNo=" + ArticleNo + ", brand=" + brand + ", quantity=" + quantity + ", mrp=" + mrp + ", pp=" + pp + '}';
    }
    
    
}
