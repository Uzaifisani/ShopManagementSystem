/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shop.management.system.common;

import java.awt.Desktop;
import java.io.File;
import javax.swing.JOptionPane;

/**
 *
 * @author uzaifisani
 */
public class OpenPdf {
    public static void openById(String id){
    try{
        File pdfFile = new File("/Users/uzaifisani/Documents/" + id + ".pdf");

            if (pdfFile.exists()) {
                Desktop.getDesktop().open(pdfFile);
                JOptionPane.showMessageDialog(null, "Bill Opened");
            } else {
                JOptionPane.showMessageDialog(null, "File Doesn't Exist");
            }

    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null, e);
    }
    }
    
}
